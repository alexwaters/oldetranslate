<?php require_once("../includes/initialize.php"); ?>
<?php include_layout_template('header.php'); ?>
<?php include_layout_template('footer.php'); ?>