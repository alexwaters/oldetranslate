<html>
  <head>
    <title>Ye Olde Translator</title>
    <link href="stylesheets/main.css" media="all" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <div id="header">
      <h1>Ye Olde Translater</h1>
    </div>
    <div id="main">
